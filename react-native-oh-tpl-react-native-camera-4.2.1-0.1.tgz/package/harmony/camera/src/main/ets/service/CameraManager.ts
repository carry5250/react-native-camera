/*
 * Copyright (c) 2024 Huawei Device Co., Ltd. All rights reserved
 * Use of this source code is governed by a MIT license that can be
 * found in the LICENSE file.
 */

import { camera } from '@kit.CameraKit';
import PermissionUtils from '../utils/PermissionUtils'
import { Constants } from '../common/Constants';
import Logger from '../utils/Logger'
import CameraService from './CameraService';
import {
  CameraIdsType,
  HardwareCamera,
  RecordOptions,
  RecordResponse,
  TakePictureOptions,
  TakePictureResponse
} from '../types';


/*
 * 相机管理器
 * */

const TAG: string = 'CameraManager';

class CameraManager {
  constructor() {
  }

  /*
   * 检查相机权限
   * */
  checkDeviceCameraAuthorizationStatus(): boolean {
    let status = false;
    Logger.info(TAG, 'checkDeviceCameraAuthorizationStatus')
    try {
      status = PermissionUtils.checkPermission(Constants.CAMERA_PERMISSION);
      Logger.info(TAG, `checkDeviceCameraAuthorizationStatus-success`)
    } catch (error) {
      Logger.error(TAG, `checkDeviceCameraAuthorizationStatus-fail：${JSON.stringify(error)}`)
    }
    return status;
  }

  /*
   * 请求设备摄像头授权
   * */
  async requestDeviceCameraAuthorization() {
    let status = false;
    Logger.info(TAG, 'requestDeviceCameraAuthorization')
    try {
      status = await PermissionUtils.grantPermission([Constants.CAMERA_PERMISSION]);
    } catch (error) {
      Logger.error(TAG, `requestDeviceCameraAuthorization-fail：${JSON.stringify(error)}`)
    }
    return status
  }

  /*
 * 请求设备麦克风权限
 * */
  async requestMicrophoneAccess() {
    let status = false;
    try {
      status = await PermissionUtils.grantPermission([Constants.MICROPHONE_PERMISSION]);
    } catch (error) {
      Logger.error(TAG, `requestDeviceCameraAuthorization-fail：${JSON.stringify(error)}`)
    }
    return status
  }

  /*
   * 检查麦克风权限
   * */
  checkMicrophoneAccessStatus(): boolean {
    let status = false;
    Logger.info(TAG, 'checkDeviceCameraAuthorizationStatus')
    try {
      status = PermissionUtils.checkPermission(Constants.CAMERA_PERMISSION);
      Logger.info(TAG, `checkDeviceCameraAuthorizationStatus-success`)
    } catch (error) {
      Logger.error(TAG, `checkDeviceCameraAuthorizationStatus-fail：${JSON.stringify(error)}`)
    }
    return status;
  }

  /*
 * 获取所有相机设备
 * */
  getAvailableCameraDevices(): Array<camera.CameraDevice> {
    return CameraService.getAvailableCameraDevices()
  }

  getCameraIds(): Array<{ id: string, deviceType: string, type: number }> {
    const list = CameraService.getAvailableCameraDevices();
    return list.map(item => {
      const { cameraPosition, cameraType } = item;
      return {
        ...item,
        id: item.cameraId,
        deviceType: cameraPosition === 0 ? 'back' : "front",
        type: cameraType
      }
    })
  }

  async takePictureAsync(options: TakePictureOptions): Promise<TakePictureResponse> {
    const result = await CameraService.takePictureAsync(options);
    return;
  }

  async recordAsync(options: RecordOptions): Promise<RecordResponse> {
    const result = await CameraService.recordAsync(options);
    return;
  }

  async refreshAuthorizationStatus(): Promise<void> {
    const result = await CameraService.refreshAuthorizationStatus();
    return;
  }

  stopRecording(): void {
    CameraService.stopRecording();
  }

  pausePreview(): void {
    CameraService.pausePreview();
  }

  resumePreview(): void {
    CameraService.resumePreview();
  }

  async getAvailablePictureSizes(): Promise<string[]> {
    const result = await CameraService.getAvailablePictureSizes();
    return;
  }

  getCameraIdsAsync(): Promise<HardwareCamera[]> {
    return new Promise((resolve, reject) => {
      const ids = this.getCameraIds();
      resolve(ids)
    })
  }

  getSupportedRatiosAsync(): Promise<string[]> {
    throw new Error('Method not implemented.');
  }

  getSupportedPreviewFpsRange(): Promise<string[]> {
    throw new Error('Method not implemented.');
  }

  checkIfVideoIsValid(): Promise<boolean> {
    throw new Error('Method not implemented.');
  }

  isRecording(): Promise<boolean> {
    throw new Error('Method not implemented.');
  }
}

export default new CameraManager();