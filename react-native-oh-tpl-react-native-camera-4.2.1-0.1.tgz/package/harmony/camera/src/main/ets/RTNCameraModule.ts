import { TurboModule } from '@rnoh/react-native-openharmony/ts';
import { TM } from "@rnoh/react-native-openharmony/generated/ts"
import CameraManager from './service/CameraManager';

export class RTNCameraModule extends TurboModule implements TM.RTNCamera.Spec {
  getCameraIds(): { id: string; type?: string | undefined; }[] {
    throw new Error('Method not implemented.');
  }
  takePictureAsync(options: TM.RTNCamera.TakePictureOptions): Promise<TM.RTNCamera.TakePictureResponse> {
    throw new Error('Method not implemented.');
  }

  recordAsync(options: TM.RTNCamera.RecordOptions): Promise<TM.RTNCamera.RecordResponse> {
    throw new Error('Method not implemented.');
  }

  refreshAuthorizationStatus(): Promise<void> {
    throw new Error('Method not implemented.');
  }

  stopRecording(): void {
    throw new Error('Method not implemented.');
  }

  pausePreview(): void {
    throw new Error('Method not implemented.');
  }

  resumePreview(): void {
    throw new Error('Method not implemented.');
  }

  getAvailablePictureSizes(): Promise<string[]> {
    throw new Error('Method not implemented.');
  }

  getCameraIdsAsync(): Promise<TM.RTNCamera.HardwareCamera[]> {
    throw new Error('Method not implemented.');
  }

  getSupportedRatiosAsync(): Promise<string[]> {
    throw new Error('Method not implemented.');
  }

  getSupportedPreviewFpsRange(): Promise<string[]> {
    throw new Error('Method not implemented.');
  }

  checkIfVideoIsValid(): Promise<boolean> {
    throw new Error('Method not implemented.');
  }

  isRecording(): Promise<boolean> {
    throw new Error('Method not implemented.');
  }
  checkMicrophoneAccessStatus(): boolean {
    return CameraManager.checkMicrophoneAccessStatus()
  }

  requestMicrophonePermission(): Promise<boolean> {
    return CameraManager.requestMicrophoneAccess()
  }

  getAvailableCameraDevices(): { cameraId: string; cameraPosition: number; cameraType: number; }[] {
    return CameraManager.getAvailableCameraDevices()
  }


  requestDeviceCameraAuthorization(): Promise<boolean> {
    return CameraManager.requestDeviceCameraAuthorization();
  }

  checkDeviceCameraAuthorizationStatus(): boolean {
    return CameraManager.checkDeviceCameraAuthorizationStatus();
  }
}